package id.ac.ui.cs.mobileprogramming.nadhirsyah.floristlog.utils

class Constants {
    companion object{
        const val BASE_URL = "https://pastebin.com"
    }
}
