package id.ac.ui.cs.mobileprogramming.nadhirsyah.floristlog.model

data class About (
    val body : String
)